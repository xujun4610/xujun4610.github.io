
/****** Object:  Table [dbo].[fa_FileUploadList]    Script Date: 2019-12-19 9:34:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fa_FileUploadList](
	[cRecordUUID] [nvarchar](36) NOT NULL,
	[cFileUUID] [nvarchar](36) NOT NULL,
	[cFileName] [nvarchar](255) NULL,
	[cFileDesp] [nvarchar](255) NULL,
	[cFileExt] [nvarchar](10) NOT NULL,
	[cFileSize] [bigint] NOT NULL,
	[cTypeFolder] [nvarchar](16) NOT NULL,
	[cSubFolder] [nvarchar](16) NOT NULL,
	[cCreate] [nvarchar](36) NOT NULL,
	[dCreate] [datetime] NOT NULL,
	[cUpdate] [nvarchar](36) NULL,
	[dUpdate] [datetime] NULL,
	[iVersion] [int] NOT NULL,
	[cSrcObjType] [nvarchar](36) NULL,
	[cSrcPKValue] [nvarchar](36) NULL,
	[cSrcPKLnNum] [nvarchar](36) NULL,
	[iFlag] [int] NULL,
	[cSrcPlatform] [nvarchar](20) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[cRecordUUID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[fa_FileUploadList] ADD  DEFAULT ((0)) FOR [cFileSize]
GO

ALTER TABLE [dbo].[fa_FileUploadList] ADD  DEFAULT (getdate()) FOR [dCreate]
GO

ALTER TABLE [dbo].[fa_FileUploadList] ADD  DEFAULT ((1)) FOR [iVersion]
GO

ALTER TABLE [dbo].[fa_FileUploadList] ADD  DEFAULT ('Android') FOR [cSrcPlatform]
GO


